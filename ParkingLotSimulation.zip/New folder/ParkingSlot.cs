﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Linq;
using static System.Reflection.Metadata.BlobBuilder;
namespace Parking
{
    class ParkingSlot
    {
        public int SlotNumber { get; set; }
        public VehicleType Type { get; set; }
        public bool IsOccupied { get; set; }
        public string VehicleNumber { get; set; }
        public ParkingTicket Ticket { get; set; }
    }
}