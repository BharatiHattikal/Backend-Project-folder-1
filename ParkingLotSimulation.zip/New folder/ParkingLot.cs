﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Parking
{
     class ParkingLot
    {
         public List<ParkingSlot> slots;

            public void Initialization()
            {
                slots = new List<ParkingSlot>();

                int twoWheelerSlots = Validate(VehicleType.TwoWheeler);
                int fourWheelerSlots = Validate(VehicleType.FourWheeler);
                int heavyVehicleSlots = Validate(VehicleType.HeavyVehicle);

                int slotNumber = 1;

                for (int i = 0; i < twoWheelerSlots; i++)
                {
                    slots.Add(new ParkingSlot { SlotNumber = slotNumber++, Type = VehicleType.TwoWheeler });
                }

                for (int i = 0; i < fourWheelerSlots; i++)
                {
                    slots.Add(new ParkingSlot { SlotNumber = slotNumber++, Type = VehicleType.FourWheeler });
                }

                for (int i = 0; i < heavyVehicleSlots; i++)
                {
                    slots.Add(new ParkingSlot { SlotNumber = slotNumber++, Type = VehicleType.HeavyVehicle });
                }
            }
            public void SoOccupancyDetails()

            {
                Console.WriteLine("Details for Parking Slots:");
                foreach (var slot in slots)
                {
                    Console.WriteLine("Slot :" + slot.SlotNumber + "." + slot.Type + ":" + (slot.IsOccupied ? "Occupied" : "Empty"));
                }
            }
            public int Validate(VehicleType vehicleType)
            {

                int numberOfSlots;

                Console.Write("Enter the number of " + vehicleType.ToString() + " slots: ");

                while (!int.TryParse(Console.ReadLine(), out numberOfSlots) || numberOfSlots < 0)
                {
                    Console.WriteLine("Invalid input.");

                    Console.Write("Enter the number of " + vehicleType.ToString() + " slots: ");
                }
                return numberOfSlots;
            }
            public void DisplayMenu()
            {
                while (true)
                {
                    Console.WriteLine("Choose an option:");
                    Console.WriteLine("1. Display ParkingLot Details");
                    Console.WriteLine("2. Park a Vehicle");
                    Console.WriteLine("3. Unpark a Vehicle");
                    Console.WriteLine("4. Exit");

                    int choice = int.Parse(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            SoOccupancyDetails();
                            break;
                        case 2:
                            ParkVehicle();
                            break;
                        case 3:
                            UnparkVehicle();
                            break;
                        case 4:
                            Console.WriteLine("Thank you ");
                            return;
                        default:
                            Console.WriteLine("Invalid choice.");
                            break;
                    }

                }
            }

            public bool ValidteVehicleNumber(string vehicleNumber)
            {

                string pattern = @"^[A-Z]{2}\d{2}[A-Z]{2}\d{4}$";
                bool Valid = Regex.IsMatch(vehicleNumber, pattern);

                return Valid;
            }
            public void ParkVehicle()
            {
                Console.WriteLine("Enter the vehicle number:");
                string vehicleNumber = Console.ReadLine() ?? "0";

                if (!ValidteVehicleNumber(vehicleNumber))
                {
                    Console.WriteLine("Invalid vehicle number.");
                    ParkVehicle();
                    return;
                }
                Console.WriteLine("Enter the vehicle type");
                Console.WriteLine("1.TwoWheeler");
                Console.WriteLine("2.FourWheeler");
                Console.WriteLine("3. HeavyVehicle");
                Console.WriteLine("Enter the vehicle type");
                int vehicleTypeChoice = int.Parse(Console.ReadLine() ?? "0");
                VehicleType vehicleType;
                switch (vehicleTypeChoice)
                {
                    case 1:
                        vehicleType = VehicleType.TwoWheeler;
                        break;
                    case 2:
                        vehicleType = VehicleType.FourWheeler;
                        break;
                    case 3:
                        vehicleType = VehicleType.HeavyVehicle;
                        break;
                    default:
                        Console.WriteLine("Invalid vehicle type.");
                        return;
                }
                ParkingSlot availableSlot = null;
                foreach (var slot in slots)
                {
                    if (slot.Type == vehicleType && !slot.IsOccupied)
                    {
                        availableSlot = slot;
                        break;
                    }
                }
                if (availableSlot != null)
                {
                    availableSlot.IsOccupied = true;
                    availableSlot.VehicleNumber = vehicleNumber;
                    availableSlot.Ticket = new ParkingTicket
                    {
                        VehicleNumber = vehicleNumber,
                        SlotNumber = availableSlot.SlotNumber,
                        InTime = DateTime.Now
                    };
                    Console.WriteLine("Vehicle parked successfully");
                    Console.WriteLine("Vehicle Number: " + vehicleNumber);
                    Console.WriteLine("Slot Number: " + availableSlot.SlotNumber);
                    Console.WriteLine("Ticket Number: " + availableSlot.Ticket.TicketNumber);
                    Console.WriteLine("In Time: " + availableSlot.Ticket.InTime);
                }
                else
                {
                    Console.WriteLine("No available slot found for the vehicle type.");
                }
            }
            public void UnparkVehicle()
            {
                Console.WriteLine("Enter the Ticket number:");
                int ticketNumber;
                if (int.TryParse(Console.ReadLine(), out ticketNumber))
                {
                    ParkingSlot occupiedSlot = null;

                    foreach (var slot in slots)
                    {
                        if (slot.IsOccupied && slot.Ticket != null && slot.Ticket.TicketNumber == ticketNumber)
                        {
                            occupiedSlot = slot;
                            break;
                        }
                    }
                    if (occupiedSlot != null)
                    {
                        occupiedSlot.IsOccupied = false;
                        occupiedSlot.Ticket.OutTime = DateTime.Now;

                        Console.WriteLine("Vehicle unparked successfully");
                        Console.WriteLine("Ticket Number: " + ticketNumber);
                        Console.WriteLine("Vehicle Number: " + occupiedSlot.Ticket.VehicleNumber);
                        Console.WriteLine("Slot Number: " + occupiedSlot.SlotNumber);
                        Console.WriteLine("In Time: " + occupiedSlot.Ticket.InTime);
                        Console.WriteLine("Out Time: " + occupiedSlot.Ticket.OutTime);
                    }
                    else
                    {
                        Console.WriteLine("Invalid ticket number");
                    }
                }
                else
                {
                    Console.WriteLine("Please enter a valid ticket number");
                }
            }


     }
}

