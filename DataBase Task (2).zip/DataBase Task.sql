CREATE TABLE Worker (
  WORKERID INT PRIMARY KEY,
  FIRSTNAME VARCHAR(50),
  LASTNAME VARCHAR(50),
  SALARY DECIMAL(10, 2),
  JOININGDATE DATE,
  DEPARTMENT VARCHAR(50)
);

INSERT INTO Worker (WORKERID, FIRSTNAME, LASTNAME, SALARY, JOININGDATE, DEPARTMENT)
VALUES
  (11, 'Bhavani', 'RopK', 50000, '2013-04-26', 'Production');


INSERT INTO Worker (WORKERID, FIRSTNAME, LASTNAME, SALARY, JOININGDATE, DEPARTMENT)
VALUES
  (1, 'Amithab', 'RK', 50000, '2023-04-26', 'FINANCE'),
  (2, 'SAHANA', 'NANI', 10000, '2023-01-26', 'SALES'),
  (3, 'MAITRI', 'KRISHNA', 3000, '2011-05-28', 'MARKETING'),
  (4, 'SATISH', 'GOKUL', 36000, '2012-12-07', 'HUMAN RESOURCE'),
  (5, 'VIPUL', 'SHIVAPUR', 100000, '2013-11-05', 'SALES'),
  (6, 'SATISH', 'NIVAR', 29000, '2015-10-04', 'ADMIN'),
  (7, 'Ananya', 'JIIT', 67000, '2021-09-10', 'HUMAN RESOURCE'),
  (8, 'MANYA', 'HHH', 90900, '2022-08-13', 'ADMIN'),
  (9, 'KAVYA', 'MRUTYA', 12000, '2021-01-22', 'MARKETING'),
  (10, 'AMULYA', 'LAVANYA', 17000, '2020-12-29', 'MARKETING')
  ;
INSERT INTO Worker (WORKERID, FIRSTNAME, LASTNAME, SALARY, JOININGDATE, DEPARTMENT)
VALUES
  (11, 'Amithab', 'RK',4555, '2022-04-26', 'FINANCE');



SELECT *
FROM WORKER;
_______________________________________________________________________________


CREATE TABLE Bonus (
  BONUSID INT PRIMARY KEY,
  WORKERID INT,
  BONUS_AMOUNT DECIMAL(10, 2),
  BONUS_DATE DATE,
  FOREIGN KEY (WORKERID) REFERENCES Worker(WORKERID)
);
INSERT INTO BONUS (BONUSID, WORKERID, BONUS_AMOUNT, BONUS_DATE)
VALUES
(1,3,10000,'2022-02-22'),
(2,5,3330,'2023-03-29'),
(3,6,2200,'2023-04-2'),
(4,2,4000,'2023-04-3'),
(5,7,7899,'2023-04-26'),
(6,10,5000,'2023-05-30'),
(7,9,1200,'2022-05-06');
SELECT *
FROM BONUS;
__________________________________________________________________________
CREATE TABLE Title (
  TITLEID INT PRIMARY KEY,
  WORKERID INT,
  WORKER_TITLE VARCHAR(50),
  GETTING_TITLEDATE  DATE,
  FOREIGN KEY (WORKERID) REFERENCES Worker(WORKERID)
);

INSERT INTO Title (TITLEID, WORKERID, WORKER_TITLE, GETTING_TITLEDATE)
VALUES
(1, 3, 'MANAGER', '2022-02-22'),
(2, 5, 'SUPERVISOR', '2015-03-29'),
(3, 6, 'ASSISTANT MANAGER', '2019-04-02'),
(4, 2, 'TEAM LEAD', '2023-04-03'),
(5,5,'PRESIDENT','2023-04-03'),
(6,6,'TEAM LEAD', '2023-04-03'),
(7, 9, 'COORDINATOR', '2022-05-06'),
(8,8,'ASSOCIATE', '2023-05-30');

_________________________________________________________________________________________
Q-1. Write an SQL query to fetch “FIRST_NAME” from Worker table using the alias name as <WORKER_NAME>.

SELECT FIRSTNAME  AS WORKER_NAME
FROM WORKER;

Q-2. Write an SQL query to fetch “FIRST_NAME” from Worker table in upper case.

SELECT UPPER(FIRSTNAME) 
FROM Worker;
Q-3. Write an SQL query to fetch unique values of DEPARTMENT from Worker table.

SELECT DISTINCT DEPARTMENT
FROM WORKER;

Q-4. Write an SQL query to print the first three characters of FIRST_NAME from Worker table.
SELECT SUBSTRING(FIRSTNAME, 1, 3) 
FROM Worker;

Q-5. Write an SQL query to find the position of the alphabet (‘a’) in the first name column ‘Amitabh’ from Worker table.

SELECT POSITION('a' IN FIRSTNAME)
FROM Worker
WHERE FIRSTNAME = 'Amithab';

Q-6. Write an SQL query to print the FIRST_NAME from Worker table after removing white spaces from the right side.
SELECT RTRIM(FIRSTNAME) 
FROM Worker;


Q-7. Write an SQL query to print the DEPARTMENT from Worker table after removing white spaces from the left side.
SELECT LTRIM(DEPARTMENT) 
FROM Worker;


Q-8. Write an SQL query that fetches the unique values of DEPARTMENT from Worker table and prints its length.

SELECT DISTINCT DEPARTMENT, LENGTH(DEPARTMENT) 
FROM Worker;

Q-9. Write an SQL query to print the FIRST_NAME from Worker table after replacing ‘a’ with ‘A’.

SELECT REPLACE(FIRSTNAME, 'A', 'a') 
FROM Worker;

Q-10. Write an SQL query to print the FIRST_NAME and LAST_NAME from Worker table into a single column COMPLETE_NAME. A space char should separate them.
SELECT CONCAT(FIRSTNAME, ' ', LASTNAME) 
FROM Worker;

Q-11. Write an SQL query to print all Worker details from the Worker table order by FIRST_NAME Ascending.
select *
from worker
order by firstname asc;
Q-12. Write an SQL query to print all Worker details from the Worker table order by FIRST_NAME Ascending and DEPARTMENT Descending.

SELECT * FROM Worker 
ORDER BY FIRSTNAME ASC, DEPARTMENT DESC;

Q-13. Write an SQL query to print details for Workers with the first name as “Vipul”  from Worker table.

select *
from worker
where firstname='VIPUL';


Q-14. Write an SQL query to print details of workers excluding first names, “Vipul” and “Satish” from Worker table.
SELECT * 
FROM Worker 
WHERE FIRSTNAME NOT IN ('VIPUL', 'SATISH');


Q-15. Write an SQL query to print details of Workers with DEPARTMENT name as “Admin”.
SELECT *
FROM WORKER
WHERE DEPARTMENT='ADMIN';

Q-16. Write an SQL query to print details of the Workers whose FIRST_NAME contains ‘M’.
SELECT *
FROM WORKER
WHERE FIRSTNAME  LIKE '%M%';
Q-17. Write an SQL query to print details of the Workers whose FIRST_NAME ends with ‘a’.
SELECT *
FROM WORKER
WHERE FIRSTNAME  LIKE '%A';

Q-18. Write an SQL query to print details of the Workers whose FIRST_NAME ends with ‘h’ and contains six alphabets.
SELECT *
FROM WORKER
WHERE FIRSTNAME  LIKE '%H' AND LENGTH(FIRSTNAME)=6;

Q-19. Write an SQL query to print details of the Workers whose SALARY lies between 100000 and 500000.
SELECT *
FROM WORKER
WHERE SALARY BETWEEN 100000 AND 500000;


Q-20. Write an SQL query to print details of the Workers who have joined in Feb’2014.

SELECT *
FROM WORKER
WHERE JOININGDATE='2013-11-05';

select *
from worker
where extract(month from JOININGDATE)=11 and
extract(year from JOININGDATE)=2013;

SELECT * FROM Worker WHERE YEAR(JOININGDATE) = 2014 AND MONTH(JOININGDATE) = 2;

Q-21. Write an SQL query to fetch the count of employees working in the department ‘Admin’.

SELECT COUNT(DEPARTMENT)
FROM WORKER
WHERE DEPARTMENT='ADMIN';

Q-22. Write an SQL query to fetch worker names with salaries >= 50000 and <= 100000.
SELECT FIRSTNAME
FROM WORKER
WHERE SALARY>=50000 and SALARY<= 100000;

Q-23. Write an SQL query to fetch the no. of workers for each department in the descending order.
SELECT DEPARTMENT, COUNT(*) 
FROM Worker
GROUP BY DEPARTMENT
ORDER BY DEPARTMENT DESC;


Q-24. Write an SQL query to print details of the Workers who are also Managers.

SELECT *
FROM Worker
WHERE WORKERID IN (
  SELECT WORKERID
  FROM Title
  WHERE WORKER_TITLE = 'MANAGER'
);

Q-26. Write an SQL query to show only odd rows from a table.

SELECT * FROM WORKER WHERE mod(WORKERID,2)> 0;


SELECT *
FROM (
  SELECT *, ROW_NUMBER() OVER (ORDER BY workerid) AS row_number
  FROM worker
) AS subquery
WHERE row_number % 2 = 1;




Q-27. Write an SQL query to show only even rows from a table.

SELECT *
FROM WORKER
WHERE MOD(WORKERID,2)=0;

Q-28. Write an SQL query to clone a new table from another table.
CREATE TABLE CLONING AS
SELECT *
FROM WORKER;


Q-29. Write an SQL query to fetch intersecting records of two tables.
SELECT FIRSTNAME, LASTNAME
FROM WORKER
INTERSECT
SELECT FIRSTNAME, LASTNAME              
FROM cloning;


Q-30. Write an SQL query to show records from one table that another table does not have.

SELECT *
FROM worker
WHERE workerid NOT IN (SELECT workerid FROM cloning);

delete 
from cloning
where workerid=11;

Q-31. Write an SQL query to show the current date and time.
SELECT current_timestamp;

Q-32. Write an SQL query to show the top n (say 10) records of a table.
SELECT *
FROM WORKER
LIMIT 5;

Q-33. Write an SQL query to determine the nth (say n=5) highest salary from a table.
SELECT SALARY
FROM WORKER
ORDER BY SALARY DESC;

SELECT salary
FROM worker
ORDER BY salary DESC
LIMIT 1 OFFSET 4;


Q-34. Write an SQL query to determine the 5th highest salary without using TOP or limit method.
SELECT MAX(SALARY)
FROM WORKER
WHERE SALARY<(SELECT MAX(SALARY)
			FROM WORKER
			  WHERE SALARY<(SELECT MAX(SALARY)
			                FROM WORKER
			                 WHERE SALARY<(SELECT MAX(SALARY)
			                                FROM WORKER
			                                 WHERE SALARY<(SELECT MAX(SALARY)
			                                                 FROM WORKER))));
SELECT DISTINCT Salary
FROM Worker w1
WHERE 5 = (
  SELECT COUNT(DISTINCT Salary)
  FROM Worker w2
  WHERE w2.Salary >= w1.Salary
);
													 
															 


Q-35. Write an SQL query to fetch the list of employees with the same salary.
SELECT *
FROM WORKER
WHERE salary IN (
  SELECT salary
  FROM WORKER
  GROUP BY salary
  HAVING COUNT(*) > 1
);



Q-36. Write an SQL query to show the second highest salary from a table.
SELECT DISTINCT Salary
FROM Worker w1
WHERE 2 = (
  SELECT COUNT(DISTINCT Salary)
  FROM Worker w2
  WHERE w2.Salary >= w1.Salary
);
Q-37. Write an SQL query to show one row twice in results from a table.
SELECT *
FROM worker
UNION ALL
SELECT *
FROM worker;

Q-38. Write an SQL query to fetch intersecting records of two tables.
(SELECT * FROM Worker)
INTERSECT
(SELECT * FROM Cloning);


Q-39. Write an SQL query to fetch the first 50% records from a table.
SELECT *
FROM WORKER
LIMIT  (SELECT COUNT(*)/2
		FROM WORKER);

Q-40. Write an SQL query to fetch the departments that have less than 3 people in it.
SELECT  department
FROM WORKER
GROUP BY DEPARTMENT
HAVING COUNT(*)<3;

Q-41. Write an SQL query to show all departments along with the number of people in there.
SELECT DEPARTMENT ,COUNT(*)
FROM WORKER
GROUP BY DEPARTMENT;

Q-42. Write an SQL query to show the last record from a table.

SELECT *
FROM WORKER
ORDER BY WORKERID DESC
LIMIT 1;

Q-43. Write an SQL query to fetch the first row of a table.

SELECT *
FROM WORKER
LIMIT 1;

Q-44. Write an SQL query to fetch the last five records from a table.
SELECT *
FROM WORKER
ORDER BY WORKERID DESC
LIMIT 5;

Q-45. Write an SQL query to print the name of employees having the highest salary in each department.
select *
from worker;

select firstname,DEPARTMENT,SALARY
from worker
where salary in( select max(salary)
			   from worker
			   group by department);


Q-46. Write an SQL query to fetch three max salaries from a table.
SELECT  SALARY
FROM Worker
ORDER BY SALARY DESC
LIMIT 3;



Q-47. Write an SQL query to fetch three min salaries from a table.
SELECT DISTINCT SALARY
FROM Worker
ORDER BY SALARY ASC
LIMIT 3;


Q-48. Write an SQL query to fetch nth max salaries from a table.

SELECT DISTINCT Salary
FROM Worker w1
WHERE n = (
  SELECT COUNT(DISTINCT Salary)
  FROM Worker w2
  WHERE w2.Salary >= w1.Salary
);

Q-49. Write an SQL query to fetch departments along with the total salaries paid for each of them.
SELECT DEPARTMENT, SUM(SALARY) 
FROM Worker
GROUP BY DEPARTMENT;




Q-50. Write an SQL query to fetch the names of workers who earn the highest salary.

 SELECT FIRSTNAME
FROM Worker
WHERE SALARY = (SELECT MAX(SALARY) FROM Worker);



